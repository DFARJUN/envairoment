function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6KZZiEk4KOz":
        Script1();
        break;
  }
}

function Script1()
{
  sendScore();
}

